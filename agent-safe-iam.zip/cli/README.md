# CLI (JS)
Build JS SDK first, then `npm run build` here and run `spl <policy> <request>`.
