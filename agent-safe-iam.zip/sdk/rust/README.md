# Rust SPL Verifier (placeholder)

Contributions welcome. Mirror the JS/Go semantics.
