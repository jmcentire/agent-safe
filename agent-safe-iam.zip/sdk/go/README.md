# Go SPL Verifier (Minimal)

Run demo:
```bash
go run ./verify ../../examples/policies/family_gifts.spl ../../examples/requests/gift_50_niece.json
```
