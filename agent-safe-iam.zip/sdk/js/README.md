# JS SPL Verifier (Minimal)

Build:
```bash
npm i
npm run build
```

Run demo:
```bash
node dist/index.js ../../examples/policies/family_gifts.spl ../../examples/requests/gift_50_niece.json
```
